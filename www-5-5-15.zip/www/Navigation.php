<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Navigation</title>

<style type="text/css">
.nav_bg li {
float: center;
display: inline;
height: 38px;
color: #fff;
font-size: 28px;
font-weight: 700;
padding: 0 20px;
margin: 0 5px;
line-height: 38px;
text-align: center;
border: 2px transparent solid;
border-radius: 5px;
behavior: url(file:///E|/Program%20Files/wamp/www/css/PIE.htc);
position: relative;
}
.nav_bg li:hover, .nav_bg li.on {
cursor: pointer;
background: #fff;
border-top: 2px #000 solid;
border-left: 2px #000 solid;
border-bottom: 2px #000 solid;
border-right: 2px #000 solid;
}
</style>
</head>

<body>
	<div class="nav_bg ma_auto">
      <ul>
        <li><a href="Home.php">Home</a></li>
        <Li><a href="Contact.php">Contact</a></Li>
        <Li><a href="About.php">About</a></Li>
      </ul>
    </div>
    <Br/>
</body>
</html>