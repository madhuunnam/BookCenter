<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>About</title>



<style>

  .action-box-rounded{
        border:1px solid;border-color:#09F;width:400px;margin:10px;margin-left:20px
   }
   
</style>

</head>


<?php include 'NavigationBar.php'; ?>


<body>
<div align="center">
<div class="action-box-rounded">

<p align="left">Our Books Online Exchange can help you find your books in nearby bookstores, libraries or personal libraries to but , rent or borrow. It can also help market your books. It is a free online service.</p>


</div>
</div>
</body>
</html>